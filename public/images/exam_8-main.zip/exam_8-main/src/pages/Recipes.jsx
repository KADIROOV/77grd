import { useState } from "react";
import RecipesHeader from "../components/RecipesHeader";

function Recipes() {
  return (
    <>
      <RecipesHeader />
    </>
  );
}

export default Recipes;

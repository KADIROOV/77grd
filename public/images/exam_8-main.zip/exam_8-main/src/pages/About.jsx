import AboutComp from "../components/AboutComp";
import InviteComp from "../components/InviteComp";

function About() {
  return (
    <>
      <AboutComp />
      <InviteComp />
    </>
  );
}

export default About;

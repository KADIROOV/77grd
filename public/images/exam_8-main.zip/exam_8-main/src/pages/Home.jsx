import HeroDesc from "../components/HeroDesc";
import InviteComp from "../components/InviteComp";

function Home() {
  return (
    <>
      <HeroDesc />
      <InviteComp />
    </>
  );
}

export default Home;
